#include <stdio.h>

 int main()

 {

   float a,b,c;

   printf("a = %f",10,"b = %f",10,"c = %f",a,b,c);

   return 0;

 }


